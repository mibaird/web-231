/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Michelle Baird
    Date:   August 12, 2025

    Filename: project01-02.js
*/

//define variables for service name and service speed

let service1Name = "Basic";

let service2Name = "Express";

let service3Name = "Extreme";

let service4Name = "Ultimate";

let service1Speed = "0 Mbps";

let service2Speed = "100 Mbps";

let service3Speed = "500 Mbps";

let service4Speed = "1 Gig";
